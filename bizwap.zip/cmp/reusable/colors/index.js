export const primary = "#752FFF";
export const secondary = "#379FFF";
export const info = "#11ABCD";
export const error = "#FF696A";
export const warning = "#FFBE00";
export const danger = "#00FFA1";
export const success = "#FE14C";
