import React from 'react';
import {Text} from 'react-native';

const Account = ()=><Text>Account</Text>

export default Account;
